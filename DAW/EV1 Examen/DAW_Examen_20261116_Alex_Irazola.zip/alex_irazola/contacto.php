<?php
session_start();
$errores = [];
$enviado = false;
$nombre = '';
$email = '';
$mensaje = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $mensaje = trim($_POST['mensaje'] ?? '');
    if ($nombre === '') $errores[] = 'Introduce tu nombre.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errores[] = 'Introduce un correo válido.';
    if ($mensaje === '') $errores[] = 'Escribe un mensaje.';
    if (!$errores) {
        $_SESSION['nombre'] = $nombre;
        $enviado = true;
    }
}
function e(string $texto): string { return htmlspecialchars($texto, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>MiniBiblioteca | Contacto</title><link rel="stylesheet" href="assets/estilos.css"></head>
<body>
<header class="cabecera"><div class="contenedor"><strong>📚 MiniBiblioteca</strong><nav><a href="index.php">Inicio</a><a href="libros.php">Catálogo</a><a class="activo" href="contacto.php">Contacto</a></nav></div></header>
<main class="contenedor estrecho"><h1>Contacto</h1><p>Prueba el envío de formularios por POST y las sesiones de PHP.</p>
<?php if ($enviado): ?><div class="aviso exito"><strong>¡Mensaje recibido, <?= e($nombre) ?>!</strong><p>Este es un formulario de demostración: el mensaje no se envía por correo ni se guarda en una base de datos.</p><a href="index.php">Volver al inicio</a></div>
<?php else: ?>
<?php if ($errores): ?><div class="aviso error"><strong>Revisa los datos:</strong><ul><?php foreach ($errores as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<form class="panel formulario" method="post" action="contacto.php">
<label for="nombre">Nombre</label><input id="nombre" name="nombre" type="text" maxlength="100" value="<?= e($nombre) ?>" required>
<label for="email">Correo electrónico</label><input id="email" name="email" type="email" maxlength="150" value="<?= e($email) ?>" required>
<label for="mensaje">Mensaje</label><textarea id="mensaje" name="mensaje" rows="5" required><?= e($mensaje) ?></textarea>
<button type="submit">Enviar mensaje</button>
</form><?php endif; ?>
</main><footer>MiniBiblioteca · Proyecto de práctica para despliegue web</footer>
</body></html>
