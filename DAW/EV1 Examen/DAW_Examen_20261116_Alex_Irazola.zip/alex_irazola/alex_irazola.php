<?php
session_start();
$nombre = $_SESSION['nombre'] ?? null;
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>MiniBiblioteca | Inicio</title>
  <link rel="stylesheet" href="assets/estilos.css">
</head>
<body>
<header class="cabecera"><div class="contenedor"><strong>📚 MiniBiblioteca</strong><nav><a class="activo" href="index.php">Inicio</a><a href="libros.php">Catálogo</a><a href="contacto.php">Contacto</a></nav></div></header>
<main class="contenedor">
  <section class="hero">
    <span class="etiqueta">Examen de despliegue · PHP</span>
    <h1>Tu próxima lectura empieza aquí</h1>
    <p>Una web sencilla con páginas dinámicas, enlaces, estilos y un formulario procesado por PHP.</p>
    <a class="boton" href="libros.php">Explorar libros</a>
  </section>
  <section class="panel"><h2>Estado de la aplicación</h2>
    <p><strong>Servidor PHP:</strong> <span class="correcto">Funcionando</span></p>
    <p><strong>Versión de PHP:</strong> <?= htmlspecialchars(PHP_VERSION) ?></p>
    <p><strong>Fecha del servidor:</strong> <?= date('d/m/Y H:i') ?></p>
    <?php if ($nombre): ?><p>Último mensaje enviado por: <strong><?= htmlspecialchars($nombre) ?></strong></p><?php endif; ?>
  </section>
</main>
<footer>MiniBiblioteca · Proyecto de práctica para despliegue web</footer>
</body>
</html>
