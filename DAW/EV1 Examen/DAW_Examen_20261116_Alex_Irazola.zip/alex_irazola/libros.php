<?php
$libros = [
    ['titulo' => 'El principito', 'autor' => 'Antoine de Saint-Exupéry', 'categoria' => 'Clásicos'],
    ['titulo' => '1984', 'autor' => 'George Orwell', 'categoria' => 'Ficción'],
    ['titulo' => 'La historia interminable', 'autor' => 'Michael Ende', 'categoria' => 'Fantasía'],
    ['titulo' => 'Frankenstein', 'autor' => 'Mary Shelley', 'categoria' => 'Clásicos'],
];
$filtro = trim($_GET['categoria'] ?? '');
$categorias = ['Clásicos', 'Ficción', 'Fantasía'];
if ($filtro && !in_array($filtro, $categorias, true)) { $filtro = ''; }
?>
<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>MiniBiblioteca | Catálogo</title><link rel="stylesheet" href="assets/estilos.css"></head>
<body>
<header class="cabecera"><div class="contenedor"><strong>📚 MiniBiblioteca</strong><nav><a href="index.php">Inicio</a><a class="activo" href="libros.php">Catálogo</a><a href="contacto.php">Contacto</a></nav></div></header>
<main class="contenedor"><h1>Catálogo de libros</h1><p>Filtra los títulos por categoría. Los libros se generan desde un array de PHP.</p>
<form class="filtros" action="libros.php" method="get"><label for="categoria">Categoría:</label><select id="categoria" name="categoria"><option value="">Todas</option><?php foreach ($categorias as $categoria): ?><option value="<?= htmlspecialchars($categoria) ?>" <?= $filtro === $categoria ? 'selected' : '' ?>><?= htmlspecialchars($categoria) ?></option><?php endforeach; ?></select><button type="submit">Filtrar</button></form>
<div class="rejilla">
<?php foreach ($libros as $libro): ?>
<?php if ($filtro !== '' && $libro['categoria'] !== $filtro) continue; ?>
<article class="tarjeta"><div class="icono-libro">📖</div><span class="etiqueta"><?= htmlspecialchars($libro['categoria']) ?></span><h2><?= htmlspecialchars($libro['titulo']) ?></h2><p><?= htmlspecialchars($libro['autor']) ?></p></article>
<?php endforeach; ?>
</div></main><footer>MiniBiblioteca · Proyecto de práctica para despliegue web</footer>
</body></html>
