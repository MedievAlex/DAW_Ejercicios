<?php
    // Comprobamos que se hayan recibido id y nombre.
    if (isset($_GET['id']) && isset($_GET['nombre'])) {
        // Recogemos los datos enviados mediante la URL.
        $id = $_GET['id'];
        $nombre = $_GET['nombre'];
        // Conectamos con la base de datos.
        $mysqli = new mysqli(
            "localhost",
            "root",
            "",
            "test"
        );
        // Comprobamos si la conexión ha fallado.
        if ($mysqli->connect_errno) {
            echo "Falló la conexión a MySQL: (" .
                $mysqli->connect_errno . ") " .
                $mysqli->connect_error;
        }
        // Preparamos la consulta INSERT.
        $sentencia = $mysqli->prepare(
            "INSERT INTO test(id, nombre) VALUES (?, ?)"
        );
        // Vinculamos los valores con los parámetros ?.
        // "i" → integer (id).
        // "s" → string (nombre).
        $sentencia->bind_param(
            "is",
            $id,
            $nombre
        );
        // Ejecutamos el INSERT.
        if (!$sentencia->execute()) {
            echo "Falló la ejecución: (" .
                $sentencia->errno . ") " .
                $sentencia->error;
        }
        // Cerramos la sentencia.
        $sentencia->close();
        // Volvemos a la lista de registros.
        header("Location: SelectTest.php");
        exit();
    } else {
        // Si falta algún parámetro, mostramos un error.
        echo "<br>Error en parámetros<br>";
    }
?>

