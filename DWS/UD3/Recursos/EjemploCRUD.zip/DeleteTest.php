<?php
    // Comprobamos que se haya recibido el parámetro id.
    if (isset($_GET['id'])) {
        // Recogemos el id enviado mediante la URL.
        $id = $_GET['id'];
        // Conectamos con la base de datos.
        $mysqli = new mysqli(
            "localhost",
            "root",
            "",
            "test"
        );
        // Comprobamos si la conexión ha fallado.
        if ($mysqli->connect_errno) {
            echo "Falló la conexión a MySQL: (" .
                $mysqli->connect_errno . ") " .
                $mysqli->connect_error;
        }
        // Preparamos la consulta SQL.
        $sentencia = $mysqli->prepare(
            "DELETE FROM test WHERE id=?"
        );
        // Vinculamos el valor de $id con el parámetro ?.
        // "i" indica que $id es un entero (integer).
        $sentencia->bind_param("i", $id);
        // Ejecutamos la consulta.
        if (!$sentencia->execute()) {
            echo "Falló la ejecución: (" .
                $sentencia->errno . ") " .
                $sentencia->error;
        }
        // Cerramos la sentencia preparada.
        $sentencia->close();
        // Volvemos a la lista de registros.
        header("Location: SelectTest.php");
        exit();
    } else {
        // Si no se ha recibido el id, mostramos un error.
        echo "<br>Error en parámetros<br>";
    }
?>

