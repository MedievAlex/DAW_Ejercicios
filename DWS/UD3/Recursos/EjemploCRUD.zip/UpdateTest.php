<?php
    // Comprobamos que se hayan recibido el id y el nombre.
    if (isset($_GET['id']) && isset($_GET['nombre'])) {
        // Recogemos los datos enviados mediante la URL.
        $id = $_GET['id'];
        $nombre = $_GET['nombre'];
        // Conectamos con la base de datos.
        $mysqli = new mysqli(
            "localhost",
            "root",
            "",
            "test"
        );
        // Comprobamos si la conexión ha fallado.
        if ($mysqli->connect_errno) {
            echo "Falló la conexión a MySQL: (" .
                $mysqli->connect_errno . ") " .
                $mysqli->connect_error;
        }
        // Preparamos la consulta UPDATE.
        $sentencia = $mysqli->prepare(
            "UPDATE test SET nombre=? WHERE id=?"
        );
        // Vinculamos los valores con los parámetros ?.
        // "s" → string → $nombre.
        // "i" → integer → $id.
        $sentencia->bind_param(
            "si",
            $nombre,
            $id
        );
        // Ejecutamos la consulta.
        if (!$sentencia->execute()) {
            echo "Falló la ejecución: (" .
                $sentencia->errno . ") " .
                $sentencia->error;
        }
        // Cerramos la sentencia preparada.
        $sentencia->close();
        // Volvemos al listado de registros.
        header("Location: SelectTest.php");
        exit();
    } else {
        // Si falta algún parámetro, mostramos un error.
        echo "<br>Error en parámetros<br>";
    }
?>
