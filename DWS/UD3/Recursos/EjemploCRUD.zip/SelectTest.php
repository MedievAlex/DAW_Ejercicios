
<?php
    //Ejecutar: http://localhost:8000/UD03/EjemploCRUD/SelectTest.php
    // Conectamos con la base de datos.
    $mysqli = new mysqli(
        "localhost",
        "root",
        "",
        "test"
    );
    // Comprobamos si la conexión ha fallado.
    if ($mysqli->connect_errno) {
        echo "Falló la conexión a MySQL: (" .
            $mysqli->connect_errno . ") " .
            $mysqli->connect_error;
    }
    // Ejecutamos la consulta para obtener todos los registros.
    $resultado = $mysqli->query(
        "SELECT * FROM test"
    );
    // Recorremos los registros obtenidos.
    while ($row = $resultado->fetch_assoc()) {
        // Mostramos los datos del registro.
        echo $row['id'] . " - " . $row['nombre'] . " - ";
        // Enviamos el id a UpdateForm.php para modificar el registro.
        echo '<a href="UpdateForm.php?id=' .
            $row['id'] .
            '">Modificar</a>';
        echo ' - ';
        // Enviamos el id a DeleteTest.php para eliminar el registro.
        echo '<a href="DeleteTest.php?id=' .
            $row['id'] .
            '">Eliminar</a>';
        // Saltamos a la siguiente línea.
        echo "<br>";
    }
    // Cerramos la conexión con la base de datos.
    $mysqli->close();
?>
<!-- Enlace para añadir un nuevo registro. -->
<br>
<a href="InsertForm.php">Añadir alumno</a>