<?php
        // Conectamos con la base de datos.
        $con = new mysqli(
            'localhost',
            'root',
            '',
            'instagram_mvc'
        );
        // Obtenemos todos los usuarios de la tabla.
        $query = $con->query(
            'SELECT * FROM usuarios'
        );
?>

<!DOCTYPE html>
    <html>
        <head>
            <meta charset="UTF-8">
            <title>Usuarios</title>
            <style>
                table, th, td {
                    border: 1px solid;
                }
            </style>
        </head>
        <body>
            <!-- Tabla donde mostraremos los usuarios. -->
            <table>
                <thead>
                    <tr>
                        <td>Usuario</td>
                        <td>Contraseña</td>
                        <td>Nombre real</td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        // Recorremos los resultados obtenidos de la consulta.
                        while ($usuario = $query->fetch_assoc()) {
                            // Creamos una fila de la tabla.
                            echo "<tr>";
                            // Mostramos los datos del usuario.
                            echo "<td>" . $usuario['username'] . "</td>";
                            echo "<td>" . $usuario['password'] . "</td>";
                            echo "<td>" . $usuario['nombre'] . "</td>";
                            // Cerramos la fila.
                            echo "</tr>";
                        }
                    ?>
                </tbody>
            </table>
        </body>
    </html>