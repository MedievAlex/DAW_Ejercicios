<?php
    //Ejecutar: http://localhost:8000/UD03/EjemploBBDD/pruebaConexion-0.ph
    // Conectamos PHP con la base de datos.
    $con = new mysqli(
        'localhost',
        'root',
        '',
        'instagram_mvc'
    );
    // Comprobamos si ha ocurrido algún error en la conexión.
    if ($con->connect_error) {
        // Si hay un error, mostramos el mensaje y detenemos el programa.
        die("Error de conexión: " . $con->connect_error);
    }
    // Si llegamos aquí, la conexión se ha realizado correctamente.
    echo "Conexión correcta con la base de datos";
?>