<?php
    // http://localhost:8000/UD03/EjemploBBDD/mostrarUsuarios.php
    // Conectamos PHP con la base de datos.
    $con = new mysqli(
        'localhost',
        'root',
        '',
        'instagram_mvc'
    );
    // Ejecutamos una consulta para obtener todos los usuarios.
    $query = $con->query(
        'SELECT * FROM usuarios'
    );
    // Comprobamos si la consulta ha producido algún error.
    if ($query === false) {
        // Mostramos el error y detenemos la ejecución.
        die("Error en la consulta: " . $con->error);
    }
    // Recorremos los usuarios obtenidos de la base de datos.
    while ($usuario = $query->fetch_assoc()) {
        // Mostramos el username de cada usuario.
        echo $usuario['username'] . '<br>';
    }
?>