<?php
//Ejecutar: http://localhost:8000/UD03/EjemploLogin/index.php
   require_once("view/login.php");
?>