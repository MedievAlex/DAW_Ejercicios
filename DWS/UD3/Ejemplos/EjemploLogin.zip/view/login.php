<!DOCTYPE html>
    <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Inicio de sesión</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body>
            <div class="container">
                <h1 class="mt-4">Inicio de sesión</h1>
                <form
                    action="controller/LoginController.php"
                    method="post"
                    class="mt-4"
                >
                    <div class="mb-3">
                        <label for="username" class="form-label">
                            Nombre de usuario
                        </label>
                        <input
                            type="text"
                            id="username"
                            name="username"
                            class="form-control"
                            required
                        >
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">
                            Contraseña
                        </label>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            class="form-control"
                            required
                        >
                    </div>
                    <button type="submit" class="btn btn-primary">
                        Iniciar sesión
                    </button>
                </form>
            </div>
        </body>
    </html>