<!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Escritorio</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
        <body>
            <div class="container">
                <h1 class="mt-4"> Bienvenido al sistema,
                    <?= htmlspecialchars($_SESSION["usuario_logueado"]) ?>
                </h1>
                <p class="mt-3">
                    Has iniciado sesión correctamente.
                </p>

                <a href="LogoutController.php" class="btn btn-danger">
                    Cerrar sesión
                </a>
            </div>
        </body>
    </html>