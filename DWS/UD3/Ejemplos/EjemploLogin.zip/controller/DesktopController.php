<?php
    // Iniciamos o recuperamos la sesión.
    session_start();
    // Comprobamos si el usuario ha iniciado sesión.
    if (!isset($_SESSION["usuario_logueado"])) {
        // Si no ha iniciado sesión, volvemos al login.
        header("Location: ../index.php");
        exit();
    }
    // Si ha iniciado sesión, mostramos la vista.
    require_once("../view/desktop.php");

?>