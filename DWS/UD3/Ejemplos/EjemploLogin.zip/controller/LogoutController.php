<?php
    // Iniciamos o recuperamos la sesión.
    session_start();
    // Eliminamos todos los datos de la sesión.
    session_destroy();
    // Volvemos al login.
    header("Location: ../index.php");
    exit();
?>