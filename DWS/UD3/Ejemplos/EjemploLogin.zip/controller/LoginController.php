<?php
    require_once("../model/Usuario.php");
    require_once("../DAO/UsuarioDAO.php");

    // Recogemos los datos enviados por el formulario.
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Creamos un objeto Usuario.
    $usuario = new Usuario(
        0,
        $username,
        $password
    );

    // Creamos el DAO.
    $dao = new UsuarioDAO();

    // Comprobamos si el usuario existe.
    $usuarioEncontrado = $dao->comprobarUsuario($usuario);


    // Comprobamos el resultado.
    if ($usuarioEncontrado != null) {

        // Iniciamos la sesión.
        session_start();

        // Guardamos el usuario en la sesión.
        $_SESSION["usuario_logueado"] =
            $usuarioEncontrado->getUsername();

        // Guardamos también el id.
        $_SESSION["id_usuario"] =
            $usuarioEncontrado->getId();

        // Redirigimos al escritorio.
        header("Location: DesktopController.php");

        exit();

    } else {

        // Usuario o contraseña incorrectos.
        header("Location: ../index.php");

        exit();
    }

?>
