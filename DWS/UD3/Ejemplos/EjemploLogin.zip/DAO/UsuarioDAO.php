<?php

    require_once("../model/Usuario.php");
    require_once("ConexionDB.php");

    class UsuarioDAO
    {
        private mysqli $conexion;

        public function __construct()
        {
            $this->conexion = ConexionDB::conexion();
        }

        // BUSCAR USUARIO POR USERNAME Y PASSWORD
        public function comprobarUsuario(Usuario $usuario): ?Usuario
        {
            $sql = "SELECT id, username, password
                    FROM usuarios
                    WHERE username = ?
                    AND password = ?";

            $stmt = $this->conexion->prepare($sql);

            $username = $usuario->getUsername();
            $password = $usuario->getPassword();

            $stmt->bind_param(
                "ss",
                $username,
                $password
            );

            $stmt->execute();

            $resultado = $stmt->get_result();

            if ($fila = $resultado->fetch_assoc()) {

                $usuario = new Usuario();

                $usuario->setId($fila["id"]);
                $usuario->setUsername($fila["username"]);
                $usuario->setPassword($fila["password"]);

                return $usuario;
            }

            return null;
        }
    }
?>