-- --------------------------------------------------------
-- Base de datos: loginmvc
-- --------------------------------------------------------

DROP DATABASE IF EXISTS `loginmvc`;

CREATE DATABASE `loginmvc`
    DEFAULT CHARACTER SET utf8mb4
    COLLATE utf8mb4_spanish_ci;

USE `loginmvc`;


-- --------------------------------------------------------
-- Tabla: usuarios
-- --------------------------------------------------------

DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
    `id` INT NOT NULL,
    `username` VARCHAR(50) NOT NULL,
    `password` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_spanish_ci;


-- --------------------------------------------------------
-- Datos de prueba
-- --------------------------------------------------------

INSERT INTO `usuarios` (`id`, `username`, `password`) VALUES
    (1, 'admin', 'admin'),
    (2, 'lorea', '1234'),
    (3, 'alumno1', '1234'),
    (4, 'alumno2', 'abcd');


-- --------------------------------------------------------
-- Comprobación
-- --------------------------------------------------------

SELECT *
FROM `usuarios`;