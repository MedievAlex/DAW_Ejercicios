CREATE DATABASE api_dwes
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE api_dwes;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE
);

INSERT INTO usuarios (nombre, email) VALUES
('Ane', 'ane@ejemplo.com'),
('Jon', 'jon@ejemplo.com'),
('Miren', 'miren@ejemplo.com');