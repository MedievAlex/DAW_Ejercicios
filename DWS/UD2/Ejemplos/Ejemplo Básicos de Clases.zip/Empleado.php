<?php

    // Definición de la clase Empleado
        class Empleado {

        private string $nombre;
        private string $puesto;
        private float $salario;

        public function __construct(string $nombre, string $puesto, float $salario) {
            $this->nombre = $nombre;
            $this->puesto = $puesto;
            $this->salario = $salario;
        }

        public function getNombre() {
            return $this->nombre;
        }

        public function getPuesto() {
            return $this->puesto;
        }

        public function getSalario() {
            return $this->salario;
        }

        public function aplicarAumento(float $porcentaje) {
            $this->salario += $this->salario * ($porcentaje / 100);
        }

        public function mostrarInfo() {
            echo "Nombre: " . $this->nombre . "<br>";
            echo "Puesto: " . $this->puesto . "<br>";
            echo "Salario: $" . $this->salario . "<br>";
        }
    }

?>