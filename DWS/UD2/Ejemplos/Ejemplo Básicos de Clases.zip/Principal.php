<?php
    // Para ejecutar: http://localhost:8000/EjemploBasicodeClases/Principal.php
    // Incluir la clase Empleado
    require_once 'Empleado.php';

    // Crear objetos Empleado
    $empleado1 = new Empleado("Ana", "Desarrolladora", 3000);
    $empleado2 = new Empleado("Luis", "Diseñador", 2500);

    // Mostrar información inicial
    echo "Información inicial:\n";
    $empleado1->mostrarInfo();
    echo "\n";
    $empleado2->mostrarInfo();
    echo "\n";

    // Aplicar aumento
    $empleado1->aplicarAumento(10); // 10% de aumento
    $empleado2->aplicarAumento(5); // 5% de aumento

    // Mostrar información después del aumento
    echo "Después del aumento:\n";
    $empleado1->mostrarInfo();
    echo "\n";
    $empleado2->mostrarInfo();