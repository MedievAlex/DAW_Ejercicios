<?php

// Clase empleado
class Empleado {

    protected string $nombre;
    protected float $salario;


    public function __construct(string $nombre, float $salario) {
        $this->nombre = $nombre;
        $this->salario = $salario;
    }


    public function getNombre() {
        return $this->nombre;
    }


    public function getSalario() {
        return $this->salario;
    }


    public function aplicarAumento(float $porcentaje) {
        $this->salario += $this->salario * ($porcentaje / 100);
    }


    public function mostrarInfo() {
        echo "Empleado: {$this->nombre}, Salario: {$this->salario}<br>";
    }
}