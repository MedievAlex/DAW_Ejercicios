<?php

    // Para ejecutar: http://localhost:8000/EjemploHerencia/Principal.php

    require_once 'Gerente.php';
    require_once 'Programador.php';
    require_once 'Empleado.php';


    // Crear un empleado genérico
    $empleado = new Empleado("Ana", 2000);
    $empleado->mostrarInfo();

    echo "<br>";


    // Crear subclases
    $gerente = new Gerente("Laura", 5000, "Ventas");
    $programador = new Programador("Carlos", 3000, "PHP");

    $gerente->mostrarInfo();
    $programador->mostrarInfo();


    echo "<br>Aplicando aumentos...<br><br>";


    // Aplicar aumentos
    $empleado->aplicarAumento(5);
    $gerente->aplicarAumento(10);
    $programador->aplicarAumento(20);


    // Mostrar info después del aumento
    $empleado->mostrarInfo();
    $gerente->mostrarInfo();
    $programador->mostrarInfo();


    echo "<br>--- Listado de empleados (polimorfismo sin abstracto) ---<br>";

    $empleados = [$empleado, $gerente, $programador];


    foreach ($empleados as $e) {
        $e->mostrarInfo();
    }

?>