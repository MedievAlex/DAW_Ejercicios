<?php

    require_once 'Empleado.php';


    class Programador extends Empleado {

        private string $lenguaje;


        public function __construct(string $nombre, float $salario, string $lenguaje) {
            parent::__construct($nombre, $salario);
            $this->lenguaje = $lenguaje;
        }


        public function mostrarInfo() {
            echo "Programador: {$this->nombre}, Salario: {$this->salario}, Lenguaje: {$this->lenguaje}<br>";
        }
    }

?>