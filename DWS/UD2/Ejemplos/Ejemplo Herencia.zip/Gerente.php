<?php

    // Definición clase Gerente
    require_once 'Empleado.php';


    class Gerente extends Empleado {

        private string $departamento;


        public function __construct(string $nombre, float $salario, string $departamento) {
            parent::__construct($nombre, $salario);
            $this->departamento = $departamento;
        }


        public function mostrarInfo() {
            echo "Gerente: {$this->nombre}, Salario: {$this->salario}, Departamento: {$this->departamento}<br>";
        }
    }

?>