<?php
require_once("controller/propietariosController.php");
require_once("view/JsonView.php");

header("Content-Type: application/json; Charset=uft-8");
header("Acces-Control-Allow-Methods: GET, PUT");

try {
    $proCon = new propietariosController();

    $metod = $_SERVER["REQUEST_METHOD"];
    $response = null;

    switch ($metod) {
        case "GET":
            $response = $proCon->consultarPropietarios();
            break;
        case "PUT":
            $response = $proCon->modificarPropietario();
            break;
        default:
            break;
    }

    JsonView::response(
        $response["codigo"],
        $response["datos"]
    );
} catch (Throwable $e) {
    JsonView::response(
        500,
        ["error" => $e->getMessage()]
    );
}
