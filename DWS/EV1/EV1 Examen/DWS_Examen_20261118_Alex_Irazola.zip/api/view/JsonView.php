<?php

class JsonView
{
    public static function response(int $codigo, mixed $datos): void
    {

        header("Content-Type: application/json; charset=utf-8");
        http_response_code($codigo);

        echo json_encode(
            $datos,
            JSON_UNESCAPED_UNICODE
                | JSON_UNESCAPED_SLASHES
                | JSON_THROW_ON_ERROR
        );
    }
}
