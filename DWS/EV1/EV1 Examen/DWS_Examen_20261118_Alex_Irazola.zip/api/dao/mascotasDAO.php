<?php
require_once("ConexionDB.php");
require_once("./model/Mascota.php");

class mascotasDAO
{
    private mysqli $con;

    public function __construct()
    {
        $this->con = ConexionDB::conexion();
    }

    public function consultarMascotas()
    {
        $mascotas = array();
        $sql = "SELECT * FROM mascotas";
        $stmt = $this->con->prepare($sql);

        try {
            $stmt->execute();
            $result = $stmt->get_result();

            while ($fila = $result->fetch_assoc()) {
                $mascota = new Mascota(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["especie"],
                    $fila["raza"],
                    $fila["fecha_nacimiento"],
                    $fila["id_propietario"]
                );
                $mascotas[] = $mascota;
            }
        } finally {
            $stmt->close();
        }
        return $mascotas;
    }

    public function consultarMascota(int $id)
    {
        $sql = "SELECT * FROM mascotas WHERE id = ?";

        $stmt = $this->con->prepare($sql);

        try {
            $stmt->bind_param(
                "i",
                $id,
            );
            $stmt->execute();
            $result = $stmt->get_result();

            while ($fila = $result->fetch_assoc()) {
                $mascota = new Mascota(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["especie"],
                    $fila["raza"],
                    $fila["fecha_nacimiento"],
                    $fila["id_propietario"]
                );
                return $mascota;
            }
            return null;
        } finally {
            $stmt->close();
        }
    }

    public function crearMascota(string $nombre, string $especie, string $raza, string $fecha_nacimiento, int $id_propietario)
    {
        $sql = "INSERT INTO mascotas (nombre, especie, raza, fecha_nacimiento, id_propietario) VALUES (?, ?, ?, ?, ?)";

        $stmt = $this->con->prepare($sql);

        try {
            $stmt->bind_param(
                "ssssi",
                $nombre,
                $especie,
                $raza,
                $fecha_nacimiento,
                $id_propietario
            );

            return $stmt->execute();
        } finally {
            $stmt->close();
        }
    }

    public function eliminarMascota(int $id)
    {
        $sql = "DELETE FROM mascotas WHERE id = ?";

        $stmt = $this->con->prepare($sql);

        try {
            $stmt->bind_param(
                "i",
                $id,
            );
            
            return $stmt->execute();
        } finally {
            $stmt->close();
        }
    }
}
