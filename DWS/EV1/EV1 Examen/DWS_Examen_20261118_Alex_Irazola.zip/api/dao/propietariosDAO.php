<?php
require_once("ConexionDB.php");
require_once("./model/Propietario.php");

class propietariosDAO
{
    private mysqli $con;

    public function __construct()
    {
        $this->con = ConexionDB::conexion();
    }

    public function consultarPropietarios(): array
    {
        $propietarios = array();
        $sql = "SELECT * FROM propietarios";
        $stmt = $this->con->prepare($sql);

        try {
            $stmt->execute();
            $result = $stmt->get_result();

            while ($fila = $result->fetch_assoc()) {
                $propietario = new Propietario(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["telefono"],
                    $fila["email"],
                );

                $propietarios[] = $propietario;
            }
        } finally {
            $stmt->close();
        }

        return $propietarios;
    }

    public function consultarPropietario(int $id)
    {
        $sql = "SELECT * FROM propietarios WHERE id = ?";
        $stmt = $this->con->prepare($sql);

        try {
            $stmt->bind_param(
                "i",
                $id
            );

            $stmt->execute();
            $result = $stmt->get_result();

            while ($fila = $result->fetch_assoc()) {
                $propietario = new Propietario(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["telefono"],
                    $fila["email"],
                );

                return $propietario;
            }
            return null;
        } finally {
            $stmt->close();
        }
    }

    public function modificarPropietario(int $id, string $nombre, string $telefono, string $email)
    {
        $sql = "UPDATE propietarios SET nombre = ?, telefono = ?, email = ? WHERE id= ?";

        $stmt = $this->con->prepare($sql);

        try {
            $stmt->bind_param(
                "sssi",
                $nombre,
                $telefono,
                $email,
                $id
            );

            return $stmt->execute();
        } finally {
            $stmt->close();
        }
    }
}
