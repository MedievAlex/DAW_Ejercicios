<?php

    class ConexionDB
    {
        // Método estático que establece la conexión
        // con la base de datos y devuelve un objeto mysqli.
        public static function conexion(): mysqli
        {
            // Creamos la conexión con MySQL.
            $conexion = new mysqli(
                "localhost",
                "root",
                "",
                "centro_veterinario"
            );

            // Indicamos que utilizaremos UTF-8.
            $conexion->set_charset("utf8mb4");

            // Devolvemos el objeto de conexión.
            return $conexion;
        }
    }

?>
