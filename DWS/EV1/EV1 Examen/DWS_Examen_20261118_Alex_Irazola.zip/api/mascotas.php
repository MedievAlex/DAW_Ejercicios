<?php
require_once("controller/mascotasController.php");
require_once("view/JsonView.php");

header("Content-Type: application/json; Charset=uft-8");
header("Acces-Control-Allow-Methods: GET, POST, DELETE");

try {
    $masCon = new mascotasController();
    $jsonView = new JsonView();

    $metod = $_SERVER["REQUEST_METHOD"];

    switch ($metod) {
        case "GET":
            $response = $masCon->consultarMascotas();
            break;
        case "POST":
            $response = $masCon->crearMascota();
            break;
        case "DELETE":
            $response = $masCon->eliminarMascota();
            break;
        default:
            break;
    }

    JsonView::response(
        $response["codigo"],
        $response["datos"]
    );
} catch (Throwable $e) {
    JsonView::response(
        500,
        ["error" => $e->getMessage()]
    );
}
