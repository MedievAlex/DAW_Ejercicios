<?php

class Mascota
{
    private int $id;
    private string $nombre;
    private string $especie;
    private string $raza;
    private string $fecha_nacimiento;
    private int $id_propietario;
    private string $nombre_propietario;

    public function __construct(
        int $id,
        string $nombre,
        string $especie,
        string $raza,
        string $fecha_nacimiento,
        int $id_propietario
    ) {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->especie = $especie;
        $this->raza = $raza;
        $this->fecha_nacimiento = $fecha_nacimiento;
        $this->id_propietario = $id_propietario;
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function setId(int $id): self
    {
        $this->id = $id;
        return $this;
    }

    public function getNombre(): string
    {
        return $this->nombre;
    }

    public function setNombre(string $nombre): self
    {
        $this->nombre = $nombre;
        return $this;
    }

    public function getEspecie(): string
    {
        return $this->especie;
    }

    public function setEspecie(string $especie): self
    {
        $this->especie = $especie;
        return $this;
    }

    public function getRaza(): string
    {
        return $this->raza;
    }

    public function setRaza(string $raza): self
    {
        $this->raza = $raza;
        return $this;
    }

    public function getFechaNacimiento(): string
    {
        return $this->fecha_nacimiento;
    }

    public function setFechaNacimiento(string $fecha_nacimiento): self
    {
        $this->fecha_nacimiento = $fecha_nacimiento;
        return $this;
    }

    public function getIdPropietario(): int
    {
        return $this->id_propietario;
    }

    public function setIdPropietario(int $id_propietario): self
    {
        $this->id_propietario = $id_propietario;
        return $this;
    }

    public function getNombrePropietario(): string
    {
        return $this->nombre_propietario;
    }

    public function setNombrePropietario(string $nombre_propietario): self
    {
        $this->nombre_propietario = $nombre_propietario;
        return $this;
    }

    public function toArray(): array
    {
        return [
            "id" => $this->id,
            "nombre" => $this->nombre,
            "especie" => $this->especie,
            "raza" => $this->raza,
            "fecha_nacimiento" => $this->fecha_nacimiento,
            "nombre_propietario" => $this->id_propietario,
        ];
    }
}
