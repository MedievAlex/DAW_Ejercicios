<?php
require_once("./dao/mascotasDAO.php");

class mascotasController
{
    private mascotasDAO $masDAO;

    public function __construct()
    {
        $this->masDAO = new mascotasDAO;
    }

    function consultarMascotas()
    {
        if (isset($_GET["id"])) {
            $mascota = $this->masDAO->consultarMascota($_GET["id"]);

            return [
                "codigo" => 200,
                "datos" => $mascota->toArray()
            ];
        } else {
            $mascotas = $this->masDAO->consultarMascotas();

            $datos = [];

            foreach ($mascotas as $mas) {
                $datos[] = $mas->toArray();
            }

            return [
                "codigo" => 200,
                "datos" => $datos
            ];
        }
    }

    function crearMascota()
    {
        $contenido = file_get_contents("php://input");
        $mas = json_decode($contenido, true);

        $this->masDAO->crearMascota($mas["nombre"], $mas["especie"], $mas["raza"], $mas["fecha_nacimiento"], $mas["id_propietario"]);

        return [
            "codigo" => 200,
            "datos" => [
                "mensaje" => "Mascota creada correctamente."
            ]
        ];
    }

    function eliminarMascota()
    {
        if (isset($_GET["id"])) {
            $this->masDAO->eliminarMascota($_GET["id"]);
        }

        return [
            "codigo" => 200,
            "datos" => [
                "mensaje" => "Mascota eliminada correctamente."
            ]
        ];
    }
}
