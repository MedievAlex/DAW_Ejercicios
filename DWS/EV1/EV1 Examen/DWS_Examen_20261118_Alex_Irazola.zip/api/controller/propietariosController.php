<?php
require_once("./dao/propietariosDAO.php");

class propietariosController
{
    private propietariosDAO $proDAO;

    public function __construct()
    {
        $this->proDAO = new propietariosDAO();
    }

    function consultarPropietarios()
    {
        if (isset($_GET["id"])) {
            $propietario = $this->proDAO->consultarPropietario($_GET["id"]);

            return [
                "codigo" => 200,
                "datos" => $propietario->toArray()
            ];
        } else {
            $propietarios = $this->proDAO->consultarPropietarios();

            $datos = [];

            foreach ($propietarios as $pro) {
                $datos[] = $pro->toArray();
            }

            return [
                "codigo" => 200,
                "datos" => $datos
            ];
        }
    }

    function modificarPropietario()
    {
        $contenido = file_get_contents("php://input");
        $pro = json_decode($contenido, true);

        $this->proDAO->modificarPropietario($pro["id"], $pro["nombre"], $pro["telefono"], $pro["email"]);

        return [
            "codigo" => 200,
            "datos" => [
                "mensaje" => "Propietario actualizado correctamente."
            ]
        ];
    }
}
