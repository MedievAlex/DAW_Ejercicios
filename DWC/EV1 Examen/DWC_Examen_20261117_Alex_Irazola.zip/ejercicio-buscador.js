// Variables
const idUsuario = document.getElementById("idUsuario");

const btnBuscar = document.getElementById("btnBuscar");
const btnLimpiar = document.getElementById("btnLimpiar");

const estado = document.getElementById("estado");

const resultado = document.getElementById("resultado");
const imagenPerfil = document.getElementById("imagenPerfil");
const spanNombre = document.getElementById("nombre");
const spanEmail = document.getElementById("email");
const spanCiudad = document.getElementById("ciudad");
const spanTemperaturaUsuario = document.getElementById("temperaturaUsuario");

// Event listeners
btnBuscar.addEventListener("click", () => {
    let id = idUsuario.value;

    if (comprobarIdUsuario(id)) {
        peticionDummyJSON(id);
    } else {
        estado.textContent = "[ERROR] El valor del ID tiene que ser entre 1 y 30."
    }
});

btnLimpiar.addEventListener("click", () => {
    resultado.style.display = "none";
});

// Comprueba si el ID introducido es válido
function comprobarIdUsuario(id) {
    let valido = false;

    if (1 <= id && id <= 30) {
        valido = true;
    }

    return valido;
}

// Hace la petición a la api DummyJSON
async function peticionDummyJSON(id) {
    let url = "https://dummyjson.com/users/" + id;
        
    try {
        const response = await fetch(url, {
            method: "GET",
            headers: { "Content-type": "aplication/json" }
        });

        const result = await response.json();

        result.then((value) => {
            imagenPerfil.src = value.image;
            spanNombre.textContent = value.firstName + " " + value.lastName;
            spanEmail.textContent = value.email;
            spanCiudad.textContent = value.address.city;

            if (isNaN(value.address.coordinates.lat) && isNaN(value.address.coordinates.lng)) {
                peticionOpenMeteo();
            } else {
                spanTemperaturaUsuario.textContent = "Desconocida.";
            }
        });
    } catch (error) {
        estado.textContent = "[ERROR] " + error.message;
    }
}

// Hace la petición a la api open meteo
async function peticionOpenMeteo(lat, lng) {
    let url = "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lng + "&current=temperature_2m" + id;

    try {
        const response = await fetch(url, {
            method: "GET",
            headers: { "Content-type": "aplication/json" }
        });

        const result = await response.json();

        result.then((value) => {
            spanTemperaturaUsuario.textContent = value.current.temperature_2m;

            resultado.style.display = "block";

            estado.textContent = "Usuario y temperatura cargados correctamente."
        });

    } catch (error) {
        estado.textContent = "[ERROR] " + error.message;
    }
}